################################
# EvoMan FrameWork - V1.0 2016 #
# Author: Karine Miras         #
# karine.smiras@gmail.com      #
################################

EvoMan is a framework for testing optimization algorithms in General Video Game Playing research field. The environment provides multiple 2D platform games to be run in several parameterized simulation modes.

Needs: numpy and pygame

 
 
